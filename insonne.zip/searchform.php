<form role="search" method="get" id="searchform" action="<?php echo home_url( '/' ); ?>">
        <input type="text" placeholder="Cerca" value="" name="s" id="s" />
        <button type="submit" id="searchsubmit"><i class="fa fa-search"></i></button>
</form>