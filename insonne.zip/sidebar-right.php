<div class="sidebarContent">
	<?php if (!function_exists('dynamic_sidebar') || !dynamic_sidebar('sidebar_tab')) : ?><?php endif; ?>
</div>